package file.mvc.model;

public class FileSet {
	public final static String FILE_DIR = "C:/Users/bit/Desktop/LZH/WEB/file_store";
	
}
